package com.RecipeCode.teamproject.reci.tag.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TagDto {
    private Long tagId;
    private String tag;
}
