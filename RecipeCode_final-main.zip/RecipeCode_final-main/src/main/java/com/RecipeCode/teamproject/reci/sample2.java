package com.RecipeCode.teamproject.reci;

public class sample2 {
}
