package com.RecipeCode.teamproject.es.search.repository;

public interface SearchLogRepository {
}
